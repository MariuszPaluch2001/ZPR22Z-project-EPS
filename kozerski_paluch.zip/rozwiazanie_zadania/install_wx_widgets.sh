#!/bin/sh
sudo add-apt-repository universe
sudo apt-get update
sudo apt-get install -y libwxgtk3.0-gtk3-dev ghostscript

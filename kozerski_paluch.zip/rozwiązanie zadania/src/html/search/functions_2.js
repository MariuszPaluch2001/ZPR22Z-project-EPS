var searchData=
[
  ['operator_2a_72',['operator*',['../classCoordinateValue.html#accbc7af44e76183d9c35a14bd3776649',1,'CoordinateValue::operator*()'],['../classResolution.html#aa5d9b96d8000913bf09b8c0961a249e3',1,'Resolution::operator*()']]],
  ['operator_2b_73',['operator+',['../classCoordinateValue.html#a38da079080f5252d596384daaed87170',1,'CoordinateValue']]],
  ['operator_2d_74',['operator-',['../classCoordinateValue.html#a7a9ff3559b834a904bbbd6f7ae05e433',1,'CoordinateValue']]],
  ['operator_2f_75',['operator/',['../classCoordinateValue.html#a4a5e6a88ab1dff5120303ff36f3fb37a',1,'CoordinateValue']]]
];

var searchData=
[
  ['setmindifference_38',['setMinDifference',['../classAlgorithm.html#a1ac776b4860d517abf19cd2c98860f24',1,'Algorithm']]],
  ['setresolution_39',['setResolution',['../classHeader.html#ad9fd8f0fb7ef69266e571e1922b2c9ea',1,'Header']]],
  ['setscalingfactor_40',['setScalingFactor',['../classAlgorithm.html#a52d99f70cb68904817bbbfe1d1684bad',1,'Algorithm']]],
  ['setsortingrange_41',['setSortingRange',['../classAlgorithm.html#a118f9e26496906fda272653258b1d381',1,'Algorithm']]],
  ['sortbatch_42',['sortBatch',['../classAlgorithm.html#a9d44d849fa66c1f1cd06eb6b32cf0ff6',1,'Algorithm']]]
];

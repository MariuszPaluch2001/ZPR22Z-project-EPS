//
// Created by kacper on 26.12.2022.
//
#include "Algorithm.hpp"
template <>
void Algorithm::sortBatch<RelativeBatch>(RelativeBatch &batch) const {}
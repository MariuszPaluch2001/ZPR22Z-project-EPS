#include "gui/GUI.h"

wxIMPLEMENT_APP(App);

